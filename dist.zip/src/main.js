import './style.css';
import { db, auth } from './firebase.js';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { onAuthStateChanged, signInAnonymously, GoogleAuthProvider, signInWithPopup, linkWithPopup, signOut } from 'firebase/auth';

// --- CONFIG & STATE ---
const STORE_KEY = 'rituario_v1';
const CODE_KEY = 'rituario_sync_code';
const THEME_KEY = 'rituario_theme';
const COLORS = ['#5c6e4e','#bd5b3a','#c79a4b','#6b7fa3','#8a5a8c'];

let state = load();
ensureMonthlyState();
let editingId = null;
let activeTab = 'daily';
let syncCode = localStorage.getItem(CODE_KEY) || null;
let cloudReady = false;
let suppressNextWrite = false;
let currentUser = null;

// --- DELEGACIÓN DE EVENTOS GLOBAL ---
document.addEventListener('click', (e) => {
  const target = e.target;

  // Tabs & Settings
  if (target.closest('#tabDailyBtn')) switchTab('daily');
  if (target.closest('#tabMonthlyBtn')) switchTab('monthly');
  if (target.closest('#syncPill')) openLinkSheet();
  if (target.closest('#btnSettings')) openSettingsSheet();
  
  // Onboarding
  if (target.closest('#btnSkipOnboarding')) skipOnboarding();
  if (target.closest('#onboardStart')) finishOnboarding();
  const onboardChip = target.closest('.onboard-chip');
  if (onboardChip) toggleOnboardChip(parseInt(onboardChip.dataset.idx));

  // Habit Actions
  const chev = target.closest('.chev');
  const card = target.closest('.card');
  if (chev) {
    activeTab === 'daily' ? openSheet(chev.dataset.edit) : openMonthlySheet(chev.dataset.edit);
  } else if (card) {
    activeTab === 'daily' ? toggleHabit(card.dataset.id) : toggleMonthlyHabit(card.dataset.id);
  }

  // Modals & Fabs
  if (target.closest('#btnAddHabit')) openSheet();
  if (target.closest('#btnAddMonthlyHabit')) openMonthlySheet();
  if (target.id === 'overlay') closeSheet();
  if (target.id === 'settingsOverlay') closeSettingsSheet();
  if (target.id === 'linkOverlay') closeLinkSheet();
  
  // Modals Buttons
  if (target.closest('#btnCancelSheet')) closeSheet();
  if (target.closest('#btnSaveHabit')) saveHabit();
  if (target.closest('#deleteBtn')) deleteHabit();
  if (target.closest('#btnCloseSettings')) closeSettingsSheet();
  if (target.closest('#btnCloseLink')) closeLinkSheet();

  // Pickers & Selectors
  if (target.closest('#iconTrigger')) toggleEmojiPicker();
  const emojiTab = target.closest('.emoji-tab');
  if (emojiTab) {
    activeEmojiCat = emojiTab.dataset.cat;
    renderEmojiTabs(document.getElementById('iconTriggerPreview').textContent);
    renderEmojiGrid(document.getElementById('iconTriggerPreview').textContent);
  }
  const emojiOpt = target.closest('.emoji-opt');
  if (emojiOpt) {
    document.querySelectorAll('.emoji-opt').forEach(x => x.classList.remove('sel'));
    emojiOpt.classList.add('sel');
    document.getElementById('iconTriggerPreview').textContent = emojiOpt.textContent;
    document.getElementById('emojiDropdown').classList.remove('open');
    document.getElementById('iconChevron').classList.remove('open');
  }
  const swatch = target.closest('.swatch');
  if (swatch) {
    document.querySelectorAll('.swatch').forEach(x => x.classList.remove('sel'));
    swatch.classList.add('sel');
  }
  const themeOpt = target.closest('.theme-opt');
  if (themeOpt) setTheme(themeOpt.dataset.theme);

  // Calendars
  if (target.closest('#calToggle')) toggleCalendar();
  if (target.closest('#btnPrevMonth')) shiftMonth(-1);
  if (target.closest('#btnNextMonth')) shiftMonth(1);
  if (target.closest('#monthlyCalToggle')) toggleMonthlyCalendar();
  if (target.closest('#btnPrevYear')) shiftYear(-1);
  if (target.closest('#btnNextYear')) shiftYear(1);

  // Auth & System
  if (target.closest('#btnSignIn')) signInWithGoogle();
  if (target.closest('#btnSignOut')) signOutGoogle();
  if (target.closest('#remindToggleBtn')) toggleReminders();
});



// --- FIREBASE MODULAR (v9) ---
onAuthStateChanged(auth, user => {
  currentUser = user;
  if(!user){
    signInAnonymously(auth).catch(() => setSyncStatus('off'));
    return;
  }
  syncCode = user.uid;
  localStorage.setItem(CODE_KEY, syncCode);
  updateAccountUI(user);
  attachCloudListener();
});

function attachCloudListener(){
  if(!syncCode) return;
  const userDoc = doc(db, 'rituario_users', syncCode);
  onSnapshot(userDoc, (document) => {
    cloudReady = true;
    if(document.exists()){
      suppressNextWrite = true;
      state = document.data();
      ensureMonthlyState();
      save(false);
      render();
      if(activeTab === 'monthly') renderMonthly();
      if(calOpen) renderCalendar();
    } else {
      pushToCloud();
    }
    setSyncStatus('live');
  }, err => {
    console.error(err);
    setSyncStatus('off');
  });
}

async function pushToCloud(){
  if(!syncCode) return;
  const userDoc = doc(db, 'rituario_users', syncCode);
  await setDoc(userDoc, state).catch(err => {
    console.error(err);
    setSyncStatus('off');
  });
}

async function signInWithGoogle(){
  const provider = new GoogleAuthProvider();
  const wasAnonymous = currentUser && currentUser.isAnonymous;
  const localStateBeforeLogin = JSON.parse(JSON.stringify(state));

  try {
    let result;
    if (wasAnonymous) {
      try {
        result = await linkWithPopup(currentUser, provider);
      } catch(err) {
        if (err.code === 'auth/credential-already-in-use') {
          result = await signInWithPopup(auth, provider);
        } else throw err;
      }
    } else {
      result = await signInWithPopup(auth, provider);
    }
    
    syncCode = result.user.uid;
    localStorage.setItem(CODE_KEY, syncCode);
    updateAccountUI(result.user);
    
    const userDocRef = doc(db, 'rituario_users', syncCode);
    const userDocSnap = await getDoc(userDocRef);
    if (!userDocSnap.exists()) {
      state = localStateBeforeLogin;
      save(true);
    }
    attachCloudListener();
  } catch (err) {
    console.error(err);
  }
}

async function signOutGoogle(){
  await signOut(auth);
  localStorage.removeItem(CODE_KEY);
  syncCode = null;
  closeLinkSheet();
  location.reload();
}


// --- CORE LOGIC & RENDER ---
function load(){
  try{
    const raw = localStorage.getItem(STORE_KEY);
    if(raw) return JSON.parse(raw);
  }catch(e){}
  return {
    habits:[
      {id:'h1', name:'Beber 2L de agua', sub:'8 vasos al día', icon:'💧', color:'#5c6e4e'},
      {id:'h2', name:'Caminar 10.000 pasos', sub:'', icon:'👣', color:'#bd5b3a'},
      {id:'h3', name:'Leer 20 minutos', sub:'', icon:'📖', color:'#c79a4b'},
    ],
    log:{},
    monthlyHabits:[
      {id:'m1', name:'Leer un libro', sub:'', icon:'📚', color:'#6b7fa3'},
      {id:'m2', name:'Ahorrar 100€', sub:'', icon:'💰', color:'#c79a4b'},
    ],
    monthlyLog:{}
  };
}

function ensureMonthlyState(){
  if(!state.monthlyHabits) state.monthlyHabits = [];
  if(!state.monthlyLog) state.monthlyLog = {};
}

function save(pushCloud = true){
  localStorage.setItem(STORE_KEY, JSON.stringify(state));
  if(pushCloud){
    if(suppressNextWrite){ suppressNextWrite = false; return; }
    pushToCloud();
  }
}

function formatDateKey(d){
  const y = d.getFullYear();
  const m = String(d.getMonth()+1).padStart(2,'0');
  const day = String(d.getDate()).padStart(2,'0');
  return `${y}-${m}-${day}`;
}
function todayKey(){ return formatDateKey(new Date()); }
function dayKey(offset){ const d = new Date(); d.setDate(d.getDate()+offset); return formatDateKey(d); }
function monthKey(d = new Date()){ return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`; }

function escapeHtml(s){
  return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function rgbToHex(rgb){
  if(rgb.startsWith('#')) return rgb;
  const m = rgb.match(/\d+/g);
  if(!m) return COLORS[0];
  return '#' + m.slice(0,3).map(x=>(+x).toString(16).padStart(2,'0')).join('');
}

function render(){
  const dl = document.getElementById('dateline');
  dl.textContent = new Date().toLocaleDateString('es-ES', {weekday:'long', day:'numeric', month:'long'});

  const tKey = todayKey();
  const todayLog = state.log[tKey] || {};
  const list = document.getElementById('habitsList');
  list.innerHTML = '';
  
  state.habits.forEach(h => {
    const done = !!todayLog[h.id];
    list.insertAdjacentHTML('beforeend', `
      <div class="card ${done ? 'done' : ''}" style="--accent: ${h.color}" data-id="${h.id}">
        <div class="seal">
          <span class="icon-glyph">${h.icon}</span>
          <svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
        </div>
        <div class="meta">
          <div class="name">${escapeHtml(h.name)}</div>
          ${h.sub ? `<div class="sub">${escapeHtml(h.sub)}</div>` : ''}
        </div>
        <div class="chev" data-edit="${h.id}">✎</div>
      </div>
    `);
  });

  renderStreak();
  renderSummary();
}

function renderMonthly(){
  const mKey = monthKey();
  const now = new Date();
  const monthName = now.toLocaleDateString('es-ES', {month:'long', year:'numeric'});
  document.getElementById('monthLabel').textContent = monthName.charAt(0).toUpperCase() + monthName.slice(1);

  const monthLog = state.monthlyLog[mKey] || {};
  const list = document.getElementById('monthlyList');
  list.innerHTML = '';

  state.monthlyHabits.forEach(h => {
    const done = !!monthLog[h.id];
    list.insertAdjacentHTML('beforeend', `
      <div class="card ${done ? 'done' : ''}" style="--accent: ${h.color}" data-id="${h.id}">
        <div class="seal">
          <span class="icon-glyph">${h.icon}</span>
          <svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
        </div>
        <div class="meta">
          <div class="name">${escapeHtml(h.name)}</div>
          ${h.sub ? `<div class="sub">${escapeHtml(h.sub)}</div>` : ''}
        </div>
        <div class="chev" data-edit="${h.id}">✎</div>
      </div>
    `);
  });

  document.getElementById('monthlyEmptyHint').style.display = state.monthlyHabits.length===0 ? 'block' : 'none';
  const done = state.monthlyHabits.filter(h => monthLog[h.id]).length;
  document.getElementById('monthlyCount').textContent = `${done}/${state.monthlyHabits.length}`;
}

function switchTab(tab){
  activeTab = tab;
  document.getElementById('tabDailyBtn').classList.toggle('sel', tab === 'daily');
  document.getElementById('tabMonthlyBtn').classList.toggle('sel', tab === 'monthly');
  document.getElementById('dailySection').style.display = tab === 'daily' ? '' : 'none';
  document.getElementById('monthlySection').style.display = tab === 'monthly' ? '' : 'none';
  document.getElementById('mainTitle').textContent = tab === 'daily' ? 'Hoy' : 'Este mes';
  if(tab === 'monthly') renderMonthly();
}


/// --- INTERACTIONS ---
function toggleHabit(id) {
  // BLOQUEO: Si el día visualizado es anterior a hoy, no hacer nada
  if (currentViewDate < new Date().setHours(0, 0, 0, 0)) return;

  const tKey = formatDateKey(currentViewDate);
  if (!state.log[tKey]) state.log[tKey] = {};
  
  const wasComplete = dayComplete(tKey);
  const turningOn = !state.log[tKey][id];
  state.log[tKey][id] = turningOn;
  
  save();
  render(currentViewDate); // Usamos la fecha seleccionada
  
  playTick(turningOn);
  vibrate(turningOn ? 15 : 8);

  if (!wasComplete && dayComplete(tKey)) celebrateDay();
}

function toggleMonthlyHabit(id) {
  const mKey = monthKey(currentViewDate);
  if (!state.monthlyLog[mKey]) state.monthlyLog[mKey] = {};
  
  const wasComplete = monthlyComplete(mKey);
  const turningOn = !state.monthlyLog[mKey][id];
  state.monthlyLog[mKey][id] = turningOn;
  
  save();
  renderMonthly();

  playTick(turningOn);
  vibrate(turningOn ? 15 : 8);

  if (!wasComplete && monthlyComplete(mKey)) celebrateDay('¡Objetivo cumplido! 🎉');
}

function dayComplete(key) {
  const log = state.log[key];
  return log && state.habits.length > 0 && state.habits.every(h => !!log[h.id]);
}

function monthlyComplete(key) {
  const log = state.monthlyLog[key];
  return log && state.monthlyHabits.length > 0 && state.monthlyHabits.every(h => !!log[h.id]);
}

function renderStreak() {
  const dotsEl = document.getElementById('streakDots');
  dotsEl.innerHTML = '';
  // Mantenemos la lógica original de racha de 14 días
  for (let i = -13; i <= 0; i++) {
    const key = dayKey(i);
    const status = dayStatus(key); // Tu función que devuelve 'green', 'yellow' o 'red'
    
    const d = document.createElement('div');
    // Usamos las nuevas clases para el color
    d.className = `d ${status === 'green' ? 'full' : ''} ${i === 0 ? 'today' : ''} ${status}`;
    dotsEl.appendChild(d);
  }
  function renderStreak() {
  const dotsEl = document.getElementById('streakDots');
  dotsEl.innerHTML = '';
  for(let i=-13; i<=0; i++) {
    const key = dayKey(i);
    const status = dayStatus(key); // Tu función que devuelve 'green', 'yellow', 'red'
    const d = document.createElement('div');
    d.className = `d ${status}`; // Aquí inyectamos el color
    dotsEl.appendChild(d);
  }
}
  // Calculamos la racha total (solo para hoy)
  let streak = 0;
  for(let i=0;;i--){
    if(dayComplete(dayKey(i))) streak++; else break;
    if(i < -60) break;
  }
  document.getElementById('streakNum').textContent = streak === 0 ? 'Empieza hoy' : `${streak} día${streak>1?'s':''} seguido${streak>1?'s':''}`;
}

function renderSummary() {
  const tKey = formatDateKey(currentViewDate); // Usamos la fecha seleccionada
  const todayLog = state.log[tKey] || {};
  const total = state.habits.length;
  const done = state.habits.filter(h => todayLog[h.id]).length;
  document.getElementById('summary').innerHTML = total === 0 ? '' : `<b>${done}/${total}</b> completados en esta fecha`;
}

// --- MODALS & FORMS ---
let sheetMode = 'daily';
function listForMode(mode){ return mode === 'monthly' ? state.monthlyHabits : state.habits; }

function openSheet(id){ sheetMode = 'daily'; openSheetCommon(id, 'Nuevo hábito', 'Editar hábito'); }
function openMonthlySheet(id){ sheetMode = 'monthly'; openSheetCommon(id, 'Nuevo objetivo mensual', 'Editar objetivo'); }

function openSheetCommon(id, newTitle, editTitle){
  editingId = id || null;
  const title = document.getElementById('sheetTitle');
  const delBtn = document.getElementById('deleteBtn');
  const nameEl = document.getElementById('fName');
  const subEl = document.getElementById('fSub');

  let h = {name:'', sub:'', icon: sheetMode === 'monthly' ? '🎯' : '💧', color:COLORS[0]};
  if(editingId){
    h = listForMode(sheetMode).find(x => x.id === editingId);
    title.textContent = editTitle;
    delBtn.style.display = 'block';
  } else {
    title.textContent = newTitle;
    delBtn.style.display = 'none';
  }
  nameEl.value = h.name;
  subEl.value = h.sub;
  nameEl.placeholder = sheetMode === 'monthly' ? 'p. ej. Leer un libro' : 'p. ej. Beber 2L de agua';
  subEl.placeholder = sheetMode === 'monthly' ? 'p. ej. Antes de fin de mes' : 'p. ej. 8 vasos al día';

  document.getElementById('iconTriggerPreview').textContent = h.icon;
  document.getElementById('emojiDropdown').classList.remove('open');
  document.getElementById('iconChevron').classList.remove('open');

  activeEmojiCat = CATEGORY_KEYS.find(cat => EMOJI_CATEGORIES[cat].includes(h.icon)) || CATEGORY_KEYS[0];
  renderEmojiTabs(h.icon);
  renderEmojiGrid(h.icon);

  const colorPicker = document.getElementById('colorPicker');
  colorPicker.innerHTML = '';
  COLORS.forEach(c => {
    const b = document.createElement('div');
    b.className = 'swatch' + (c === h.color ? ' sel':'');
    b.style.background = c;
    colorPicker.appendChild(b);
  });

  document.getElementById('overlay').classList.add('open');
}

function closeSheet(){
  document.getElementById('overlay').classList.remove('open');
  editingId = null;
}

function saveHabit(){
  const name = document.getElementById('fName').value.trim();
  if(!name){ document.getElementById('fName').focus(); return; }
  const sub = document.getElementById('fSub').value.trim();
  const icon = document.getElementById('iconTriggerPreview').textContent || '💧';
  const color = document.querySelector('.swatch.sel')?.style.background || COLORS[0];
  const list = listForMode(sheetMode);

  if(editingId){
    const h = list.find(x => x.id === editingId);
    h.name=name; h.sub=sub; h.icon=icon; h.color=rgbToHex(color);
  } else {
    list.push({id:'h'+Date.now(), name, sub, icon, color:rgbToHex(color)});
  }
  save();
  closeSheet();
  render();
  if(sheetMode === 'monthly') renderMonthly();
}

function deleteHabit(){
  if(!editingId) return;
  if(sheetMode === 'monthly'){
    state.monthlyHabits = state.monthlyHabits.filter(h => h.id !== editingId);
  } else {
    state.habits = state.habits.filter(h => h.id !== editingId);
  }
  save();
  closeSheet();
  render();
  if(sheetMode === 'monthly') renderMonthly();
}

function setSyncStatus(mode){
  const dot = document.getElementById('syncDot');
  if(!dot) return;
  dot.className = 'dot-sync ' + (mode === 'live' ? 'live' : mode === 'off' ? 'off' : '');
  document.getElementById('syncText').textContent = mode === 'live' ? 'sincronizado' : mode === 'off' ? 'solo local' : 'conectando…';
}

function updateAccountUI(user){
  if(user && !user.isAnonymous){
    document.getElementById('loggedOutView').style.display = 'none';
    document.getElementById('loggedInView').style.display = 'block';
    document.getElementById('accountAvatar').src = user.photoURL || '';
    document.getElementById('accountName').textContent = user.displayName || 'Tu cuenta';
    document.getElementById('accountEmail').textContent = user.email || '';
  } else {
    document.getElementById('loggedOutView').style.display = 'block';
    document.getElementById('loggedInView').style.display = 'none';
  }
}

function openLinkSheet(){ document.getElementById('linkOverlay').classList.add('open'); }
function closeLinkSheet(){ document.getElementById('linkOverlay').classList.remove('open'); }
function openSettingsSheet(){ document.getElementById('settingsOverlay').classList.add('open'); updateReminderUI(); }
function closeSettingsSheet(){ document.getElementById('settingsOverlay').classList.remove('open'); }


// --- EMOJIS & ONBOARDING ---
const EMOJI_CATEGORIES = {
  '🙂': ['😀','😃','😄','😁','😆','😅','🤣','😂','🙂','🙃','😉','😊','😇','🥰','😍','🤩','😘','😗','😋','😛','😜','🤪','😝','🤑','🤗','🤭','🤫','🤔','🤐','😐','😑','😶','😏','😒','🙄','😬','🤥','😌','😔','😪','🤤','😴','😷','🤒','🤕','🤢','🤮','🥵','🥶','😵','🤯','🥳','😎','🤓','🧐','😕','😟','🙁','😮','😯','😲','😳','🥺','😦','😨','😰','😥','😢','😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤','😡','😠','🤬','😈','💀','💩'],
  '✋': ['👋','🤚','🖐️','✋','🖖','👌','🤌','🤏','✌️','🤞','🤟','🤘','🤙','👈','👉','👆','🖕','👇','☝️','👍','👎','✊','👊','🤛','🤜','👏','🙌','👐','🤲','🙏','✍️','💅','🤳','💪','🦾','🦵','🦶','👂','🦻','👃','🧠','🦷','👀','👁️','👅','👄'],
  '🏃': ['🏃','🏃‍♀️','🚶','🚶‍♀️','🧘','🧘‍♀️','🏋️','🏋️‍♀️','🤸','🤸‍♀️','⛹️','🤾','🏌️','🏄','🏊','🤽','🚴','🚵','🤺','🤼','🤹','🧗','🏇','⛷️','🏂','🤿','🚣','🛌','🛀','🧖','💃','🕺','👯','🤝','💑','💏'],
  '💧': ['💧','💦','🌊','🔥','⭐','🌟','✨','⚡','☀️','🌙','⛅','☁️','🌈','❄️','💤','💢','💥','💫','🌸','🌺','🌻','🌼','🌷','🌹','🍀','🌱','🌳','🍃','🌵','🪴'],
  '🍎': ['🍎','🍊','🍋','🍌','🍉','🍇','🍓','🫐','🍒','🍑','🥭','🍍','🥥','🥝','🍅','🥑','🥦','🥬','🥒','🌶️','🫑','🌽','🥕','🧄','🧅','🥔','🍠','🥐','🍞','🥖','🥗','🥙','🍕','🍔','🌭','🌮','🌯','🥪','🍳','🥘','🍲','🍜','🍣','🍱','🥟','🍿','🧂','🥫','🍰','🎂','🍪','🍩','🍫','🍬','🍭','🍵','☕','🥤','🧃','🍺','🍷','🥂','💧'],
  '⚽': ['⚽','🏀','🏈','⚾','🥎','🎾','🏐','🏉','🥏','🎱','🪀','🏓','🏸','🥅','⛳','🪁','🏹','🎣','🤿','🥊','🥋','🎽','🛹','🛼','🛷','⛸️','🥌','🎿','⛷️','🏂','🏋️','🤼','🤸','⛹️','🤺','🤾','🏌️','🏇','🧘'],
  '📚': ['📚','📖','📝','✏️','🖊️','🖋️','📔','📕','📗','📘','📙','📓','📒','📃','📄','📑','🔖','🏷️','💼','📁','📂','🗂️','📅','📆','🗒️','🗓️','📇','📈','📉','📊','📌','📍','📎','🖇️','📏','📐','✂️','🗃️','🗄️','🗑️'],
  '🎯': ['🎯','🎲','🎮','🎧','🎵','🎶','🎤','🎸','🎹','🎨','🎭','🎬','📷','📸','🎥','💡','🔦','🕯️','💰','💵','💳','📱','💻','⌚','⏰','⏱️','⏲️','🕰️','🧭','🔑','🔒','🛠️','🔧','🔨','⚙️','🧹','🧺','🧼','🪥','🚿','🛁','🪒'],
  '❤️': ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❣️','💕','💞','💓','💗','💖','💘','💝','💟','☮️','✝️','☪️','🕉️','☸️','✡️','🔯','♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓','🆗','✅','✔️','☑️','✳️','❌','❗','❓','💯','🔄']
};
const CATEGORY_KEYS = Object.keys(EMOJI_CATEGORIES);
let activeEmojiCat = CATEGORY_KEYS[0];

function toggleEmojiPicker(){
  document.getElementById('emojiDropdown').classList.toggle('open');
  document.getElementById('iconChevron').classList.toggle('open');
}

function renderEmojiTabs(selectedIcon){
  const tabsEl = document.getElementById('emojiTabs');
  tabsEl.innerHTML = '';
  CATEGORY_KEYS.forEach(cat => {
    tabsEl.insertAdjacentHTML('beforeend', `<button type="button" class="emoji-tab ${cat === activeEmojiCat ? 'sel' : ''}" data-cat="${cat}">${cat}</button>`);
  });
}

function renderEmojiGrid(selectedIcon){
  const emojiPicker = document.getElementById('emojiPicker');
  emojiPicker.innerHTML = '';
  EMOJI_CATEGORIES[activeEmojiCat].forEach(em => {
    emojiPicker.insertAdjacentHTML('beforeend', `<div class="emoji-opt ${em === selectedIcon ? 'sel' : ''}">${em}</div>`);
  });
}

const ONBOARD_KEY = 'rituario_onboarded';
const HABIT_SUGGESTIONS = [
  {name:'Beber 2L de agua', sub:'8 vasos al día', icon:'💧'},
  {name:'Caminar 10.000 pasos', sub:'', icon:'👣'},
  {name:'Leer 20 minutos', sub:'', icon:'📖'},
  {name:'Meditar', sub:'10 minutos', icon:'🧘'},
  {name:'Hacer ejercicio', sub:'', icon:'🏋️'},
  {name:'Dormir 8 horas', sub:'', icon:'😴'},
  {name:'Comer sano', sub:'', icon:'🥗'},
  {name:'Escribir diario', sub:'', icon:'✍️'},
  {name:'Reducir pantalla', sub:'', icon:'📵'},
  {name:'Estirar', sub:'5 minutos', icon:'🤸'},
  {name:'Ahorrar', sub:'', icon:'💰'},
  {name:'Practicar gratitud', sub:'', icon:'🙏'},
];
let onboardSelected = new Set();

function renderOnboardGrid(){
  const grid = document.getElementById('onboardGrid');
  grid.innerHTML = '';
  HABIT_SUGGESTIONS.forEach((s, i) => {
    grid.insertAdjacentHTML('beforeend', `<div class="onboard-chip ${onboardSelected.has(i) ? 'sel' : ''}" data-idx="${i}"><span class="em">${s.icon}</span><span>${s.name}</span></div>`);
  });
}

function toggleOnboardChip(i){
  onboardSelected.has(i) ? onboardSelected.delete(i) : onboardSelected.add(i);
  renderOnboardGrid();
  document.getElementById('onboardStart').textContent = onboardSelected.size > 0 ? `Empezar con ${onboardSelected.size}` : 'Empezar';
}

function maybeShowOnboarding(){
  if(localStorage.getItem(ONBOARD_KEY)) return;
  onboardSelected = new Set([0,1,2]); 
  renderOnboardGrid();
  document.getElementById('onboardStart').textContent = `Empezar con ${onboardSelected.size}`;
  document.getElementById('onboardOverlay').classList.add('open');
}

function skipOnboarding(){
  localStorage.setItem(ONBOARD_KEY, '1');
  document.getElementById('onboardOverlay').classList.remove('open');
}

function finishOnboarding(){
  if(onboardSelected.size > 0){
    state.habits = [...onboardSelected].map((i, idx) => ({
      id:'h'+Date.now()+idx, name:HABIT_SUGGESTIONS[i].name, sub:HABIT_SUGGESTIONS[i].sub, icon:HABIT_SUGGESTIONS[i].icon, color:COLORS[idx % COLORS.length]
    }));
    save(); render();
  }
  skipOnboarding();
}


// --- CALENDARS ---
let calOpen = false;
let calDate = new Date();
const MONTH_NAMES = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
const WEEKDAY_LETTERS = ['L','M','X','J','V','S','D'];

function toggleCalendar(){ calOpen = !calOpen; document.getElementById('calendarPanel').classList.toggle('open', calOpen); document.getElementById('calToggle').classList.toggle('open', calOpen); if(calOpen) renderCalendar(); }
function shiftMonth(delta){ calDate.setMonth(calDate.getMonth() + delta); renderCalendar(); }

function dayStatus(key){
  const log = state.log[key];
  const total = state.habits.length;
  if(total === 0 || !log) return 'nodata';
  const done = state.habits.filter(h => log[h.id]).length;
  return total - done === 0 ? 'green' : (total - done <= 2 ? 'yellow' : 'red');
}

function renderCalendar(){
  document.getElementById('calWeekdays').innerHTML = WEEKDAY_LETTERS.map(l => `<span>${l}</span>`).join('');
  document.getElementById('calMonthLabel').textContent = `${MONTH_NAMES[calDate.getMonth()]} ${calDate.getFullYear()}`;
  
  const grid = document.getElementById('calGrid');
  grid.innerHTML = '';
  const year = calDate.getFullYear();
  const month = calDate.getMonth();
  const daysInMonth = new Date(year, month+1, 0).getDate();
  let startOffset = new Date(year, month, 1).getDay() - 1;
  if(startOffset < 0) startOffset = 6;

  for(let i=0; i<startOffset; i++) grid.insertAdjacentHTML('beforeend', '<div class="cal-cell empty"></div>');
  for(let d=1; d<=daysInMonth; d++){
    const key = formatDateKey(new Date(year, month, d));
    const todayK = todayKey();
    let cls = key > todayK ? 'future' : dayStatus(key);
    if(key === todayK) cls += ' today';
    grid.insertAdjacentHTML('beforeend', `<div class="cal-cell ${cls}">${d}</div>`);
  }
}

let monthCalOpen = false;
let monthCalYear = new Date().getFullYear();
const MONTH_ABBR = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];

function toggleMonthlyCalendar(){ monthCalOpen = !monthCalOpen; document.getElementById('monthlyCalendarPanel').classList.toggle('open', monthCalOpen); document.getElementById('monthlyCalToggle').classList.toggle('open', monthCalOpen); if(monthCalOpen) renderMonthlyCalendar(); }
function shiftYear(delta){ monthCalYear += delta; renderMonthlyCalendar(); }

function renderMonthlyCalendar(){
  document.getElementById('calYearLabel').textContent = monthCalYear;
  const grid = document.getElementById('monthGrid');
  grid.innerHTML = '';

  for(let m=0; m<12; m++){
    const key = `${monthCalYear}-${String(m+1).padStart(2,'0')}`;
    const isFuture = monthCalYear > new Date().getFullYear() || (monthCalYear === new Date().getFullYear() && m > new Date().getMonth());
    
    let cls = isFuture ? 'future' : (() => {
      const log = state.monthlyLog[key];
      if(!log || state.monthlyHabits.length === 0) return 'nodata';
      const missing = state.monthlyHabits.length - state.monthlyHabits.filter(h => log[h.id]).length;
      return missing === 0 ? 'green' : (missing <= 2 ? 'yellow' : 'red');
    })();
    if(monthCalYear === new Date().getFullYear() && m === new Date().getMonth()) cls += ' current';

    const done = state.monthlyLog[key] ? state.monthlyHabits.filter(h => state.monthlyLog[key][h.id]).length : 0;
    const frac = (!isFuture && state.monthlyHabits.length > 0) ? `<span class="frac">${done}/${state.monthlyHabits.length}</span>` : '';
    grid.insertAdjacentHTML('beforeend', `<div class="month-cell ${cls}"><span>${MONTH_ABBR[m]}</span>${frac}</div>`);
  }
}


// --- THEME, SOUNDS & EFFECTS ---
function applyTheme(mode){
  let resolved = mode === 'auto' ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') : mode;
  document.documentElement.setAttribute('data-theme', resolved);
}
function setTheme(mode){
  localStorage.setItem(THEME_KEY, mode);
  applyTheme(mode);
  document.querySelectorAll('.theme-opt').forEach(b => b.classList.toggle('sel', b.dataset.theme === mode));
}
function initTheme(){
  const saved = localStorage.getItem(THEME_KEY) || 'auto';
  applyTheme(saved);
  document.querySelectorAll('.theme-opt').forEach(b => b.classList.toggle('sel', b.dataset.theme === saved));
  if(saved === 'auto' && window.matchMedia) window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if((localStorage.getItem(THEME_KEY)||'auto') === 'auto') applyTheme('auto'); });
}

let audioCtx = null;
function playTick(rising){
  try{
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const o = audioCtx.createOscillator(), g = audioCtx.createGain();
    o.connect(g); g.connect(audioCtx.destination);
    o.type = 'sine';
    const t = audioCtx.currentTime;
    o.frequency.setValueAtTime(rising ? 520 : 320, t);
    o.frequency.exponentialRampToValueAtTime(rising ? 880 : 200, t + 0.09);
    g.gain.setValueAtTime(0.08, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
    o.start(t); o.stop(t + 0.13);
  }catch(e){}
}
function vibrate(ms){ if(navigator.vibrate) navigator.vibrate(ms); }

function celebrateDay(message = '¡Día completo! 🎉'){
  const layer = document.createElement('div'); layer.className = 'confetti-layer';
  const colors = [getComputedStyle(document.documentElement).getPropertyValue('--moss'), getComputedStyle(document.documentElement).getPropertyValue('--clay'), getComputedStyle(document.documentElement).getPropertyValue('--gold')];
  for(let i=0;i<28;i++){
    const p = document.createElement('span'); p.className = 'confetti-piece';
    p.style.left = (Math.random()*100) + 'vw'; p.style.background = colors[i % colors.length];
    p.style.animationDelay = (Math.random()*0.4) + 's'; p.style.transform = `rotate(${Math.random()*360}deg)`;
    layer.appendChild(p);
  }
  const banner = document.createElement('div'); banner.className = 'celebrate-banner'; banner.textContent = message;
  document.body.appendChild(layer); document.body.appendChild(banner);
  vibrate([15,60,15,60,30]);
  setTimeout(() => banner.classList.add('show'), 20);
  setTimeout(() => banner.classList.remove('show'), 2200);
  setTimeout(() => { layer.remove(); banner.remove(); }, 2800);
}


// --- REMINDERS ---
const REMIND_KEY = 'rituario_reminders_on';
const REMIND_LASTDATE_KEY = 'rituario_reminders_lastfire';
const REMIND_MESSAGES = ['Te quedan menos de 8 horas para marcar tus objetivos.', '¿Te has olvidado de los objetivos de hoy?'];
let reminderInterval = null;

function remindersEnabled(){ return localStorage.getItem(REMIND_KEY) === '1'; }
function updateReminderUI(){ document.getElementById('remindToggleState').textContent = (remindersEnabled() && Notification.permission === 'granted') ? 'Activado' : 'Desactivado'; }

async function toggleReminders(){
  if(!('Notification' in window)) return alert('Este navegador no admite notificaciones.');
  if(!window.isSecureContext) return alert('Los avisos solo funcionan en HTTPS.');
  if(remindersEnabled()){ localStorage.setItem(REMIND_KEY, '0'); if(reminderInterval){ clearInterval(reminderInterval); reminderInterval = null; } return updateReminderUI(); }
  if(Notification.permission === 'denied') return alert('Notificaciones bloqueadas desde el navegador.');
  if(await Notification.requestPermission() !== 'granted') return updateReminderUI();
  localStorage.setItem(REMIND_KEY, '1');
  checkReminder(); reminderInterval = setInterval(checkReminder, 15 * 60 * 1000);
  updateReminderUI();
}

function checkReminder(){
  if(!remindersEnabled() || Notification.permission !== 'granted' || state.habits.length === 0 || dayComplete(todayKey())) return;
  const now = new Date(); const endOfDay = new Date(now); endOfDay.setHours(24,0,0,0);
  if((endOfDay - now) / 3600000 > 8 || localStorage.getItem(REMIND_LASTDATE_KEY) === todayKey()) return;
  localStorage.setItem(REMIND_LASTDATE_KEY, todayKey());
  if(navigator.serviceWorker && navigator.serviceWorker.controller){
    navigator.serviceWorker.ready.then(reg => reg.showNotification('Rituario', { body: REMIND_MESSAGES[Math.floor(Math.random() * REMIND_MESSAGES.length)], icon: 'icon-192.png', badge: 'icon-192.png', tag: 'rituario-reminder' }));
  } else { try{ new Notification('Rituario', {body:REMIND_MESSAGES[0], icon:'icon-192.png'}); }catch(e){} }
}

document.addEventListener('visibilitychange', () => { if(document.visibilityState === 'visible' && remindersEnabled() && Notification.permission === 'granted') checkReminder(); });


// --- INIT ---
render();
initTheme();
maybeShowOnboarding();
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{});
if('Notification' in window && remindersEnabled() && Notification.permission === 'granted'){ checkReminder(); reminderInterval = setInterval(checkReminder, 15 * 60 * 1000); }